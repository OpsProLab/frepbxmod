# missedcallnotify
Notifications about missed calls in telegram

Модуль уведомлений о пропущенных вызовах в телеграм.
Текст уведомления настраивается в строке 69
В уведомлении используются стандартные переменные диалплана
За основу взят модуль уважаемого John Nurick
https://github.com/FreePBX-ContributedModules/missedcallnotify
(модуль очень старый и необновлялся 6 лет)
Спасибо ему за основную работу.

Модуль отредактирован мной и подправлен для телеграм

telegram @biodamage
email me@allvips.xyz

Осуществляю доработку под требования, писать на почту.